import React from 'react'
import HeroSection from '../components/home/hero-section';
import SelectedWork from '../components/home/selected-work';

const page = () => {
  return (
    <div>
      <HeroSection />
      <SelectedWork />
    </div>
  );
}

export default page
